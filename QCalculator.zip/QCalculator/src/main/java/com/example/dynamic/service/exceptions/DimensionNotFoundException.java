package com.example.dynamic.service.exceptions;

public class DimensionNotFoundException extends Exception {

	public DimensionNotFoundException(String message) {
		super(message);
	}
}
