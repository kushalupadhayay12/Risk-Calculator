package com.example.dynamic.exceptions;

public class InvalidFormulaException extends RuntimeException{

	public InvalidFormulaException(String message) {
		super(message);
	}
}
