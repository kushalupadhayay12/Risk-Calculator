package com.example.dynamic.exceptions;

public class DataAlreadyExistException extends Exception {

	public DataAlreadyExistException(String message) {
		super(message);
	}
}
